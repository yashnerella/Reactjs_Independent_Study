/**
 * Created by yashw on 08-02-2017.
 */
import React, {Component} from "react";

export class HomeNew extends Component{
    render(){
        return(
            <div>
                <h3>New Home!!!</h3>
            </div>
        );
    }
}