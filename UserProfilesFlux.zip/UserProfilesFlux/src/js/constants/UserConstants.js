/**
 * Created by yashw on 17-02-2017.
 */
export default{
    SUBMITTED_PROFILE_DETAILS: 'submitted profile details',
    CHANGE_EVENT: 'change'
}