/**
 * Created by yashw on 17-02-2017.
 */
import {Dispatcher} from 'flux';

export default new Dispatcher();