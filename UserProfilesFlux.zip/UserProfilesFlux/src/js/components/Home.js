/**
 * Created by yashw on 17-02-2017.
 */
import React,{Component} from 'react';

export class Home extends Component{
    render(){
        return(
            <div>
                <p>This application allows you to add users using "ReduceStore" concept from the
                Flux utils section. </p><hr/>
                <p>This app consists of JOI Validation.</p><hr/>
                <p>We have also done JEST Implementation</p><hr/>
            </div>
        );
    }
}