/**
 * Created by yashw on 09-04-2017.
 */
import React, {Component} from 'react';
import WeatherApp from './weatherApp';

export default class zipCodeInput extends Component{

    constructor(){
        super();
        this.state = {
            zipcode: "",
            zipSubmitted: false
        }
    }

    handleZipChange(e){
        this.setState({
            zipcode: e.target.value
        });
    }

    handleZipSubmit(){
        let tglZS = this.state.zipSubmitted;
        this.setState({zipSubmitted: !tglZS});
    }

    render(){
        if(this.state.zipSubmitted)
        return <WeatherApp zipcode={this.state.zipcode} checkAnother={this.handleZipSubmit.bind(this)}/>;
        else{
            return(
                <div className="container">
                    <well>
                    <h2>Know Weather in your area! (U.S.A only)</h2>
                    <input className="input input-sm" type="text" onChange={this.handleZipChange.bind(this)} value={this.state.zipcode}/> &nbsp;
                    <button className="btn btn-default" onClick={this.handleZipSubmit.bind(this)}>Check Weather!</button>
                    </well>
                </div>
            );
        }
    }
}