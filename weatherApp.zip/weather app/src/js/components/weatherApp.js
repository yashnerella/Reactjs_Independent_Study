/**
 * Created by yashw on 09-04-2017.
 */
import React, {Component} from 'react';
import Request from 'superagent';

export default class weatherApp extends Component{
    constructor(props){
        super(props);
        this.state = {
            weatherCity: ""
        }
    }


    componentWillMount(){
        this.fetchWeather(this.props.zipcode);
    }

    fetchWeather(zipcode = "84102"){
        let url = `http://api.openweathermap.org/data/2.5/weather?zip=${zipcode}&APPID=795f366f4a29baf4685e4bc80b9924e5`
        Request.get(url).then((response)=>{
            this.setState({weatherCity: response.body.name,
                weatherCityCoords: response.body.coord,
                weatherCityTemps: response.body.main,
                weatherCityDescription: response.body.weather[0]});
            console.log(response.body);
        })
    }

    render(){
        if(this.state.weatherCity){
            let logo = this.state.weatherCityDescription.icon;
            return(
                <div className="container">
                    place: {this.state.weatherCity}<br/>
                    latitude: {this.state.weatherCityCoords.lat} &nbsp; longitutde: {this.state.weatherCityCoords.lon}<br/>
                    humidity: {this.state.weatherCityTemps.humidity + "%"} &nbsp; pressure: {this.state.weatherCityTemps.pressure}<br/>
                    current temperature: {Math.ceil(this.state.weatherCityTemps.temp - 273) + "C"} &nbsp; max temperature: {Math.ceil(this.state.weatherCityTemps.temp_max - 273) + "C"} &nbsp;
                    min temperature: {Math.ceil(this.state.weatherCityTemps.temp_min - 273) + "C"} <br/>
                    <h4>Weather description</h4>
                    <i>{this.state.weatherCityDescription.description}</i><br/>
                    <img src={require('../../../media/' + logo + '.png')}/> <br/>
                    <button className="btn btn-default" onClick={this.props.checkAnother}>Check weather in another area</button>
                </div>
            );
        }
        else{
            return <div>loading weather....</div>;
        }
    }
}