import React from 'react';
import ReactDOM from 'react-dom';

import ZipCodeInput from './components/zipCodeInput';

ReactDOM.render(<ZipCodeInput/>, document.getElementById("root"));