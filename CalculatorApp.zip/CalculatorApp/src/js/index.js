/**
 * Created by yashw on 17-03-2017.
 */

import React from 'react';
import ReactDOM from 'react-dom';

import CalculatorContainer from './components/CalculatorContainer'

ReactDOM.render(<CalculatorContainer/>, document.getElementById("root"));