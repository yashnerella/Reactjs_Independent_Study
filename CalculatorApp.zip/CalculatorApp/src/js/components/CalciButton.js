/**
 * Created by yashw on 25-03-2017.
 */

import React from 'react';

class CalciButton extends React.Component{
    handleButtonClick(){
        if(this.props.clearDisplay)
            this.props.clearDisplay();
        else if(this.props.displayOutput)
            this.props.displayOutput();
        else
            this.props.displayInput(this.props.btnValue);
    }
    render(){
        return(<button onClick={this.handleButtonClick.bind(this)} className="btn btn-default">{this.props.btnValue}</button>);
    }
}

export default CalciButton;