/**
 * Created by yashw on 25-03-2017.
 */

import React from 'react';

import DisplayPanel from './DisplayPanel';
import CalciButton from './CalciButton';

class CalculatorContainer extends React.Component{
    constructor(){
        super();
        this.state = {
            expression: ""
        }
            this.displayUserInput = this.displayUserInput.bind(this);
            this.clearDisplayPanel = this.clearDisplayPanel.bind(this);
            this.displayUserOutput = this.displayUserOutput.bind(this);
    }

    displayUserInput(userInput){
        userInput = this.state.expression + userInput;
        this.setState({
            expression: userInput
        });
        console.log(this.state.expression);
    }

    displayUserOutput(){
        try{
            let userOutput = eval(this.state.expression);
            this.setState({
                expression:userOutput
            });
        }
        catch(e){
            this.setState({
                expression: "Error!!"
            })
        }
    }

    clearDisplayPanel(){
        this.setState({
            expression: ""
        });
    }


    render(){
        return(<div className="calculatorContainer">
            <DisplayPanel expression={this.state.expression}/>
            <br/><br/>
            <pre>
            <CalciButton btnValue="7" displayInput={this.displayUserInput}/> <CalciButton btnValue="8" displayInput={this.displayUserInput}/> <CalciButton btnValue="9" displayInput={this.displayUserInput}/> <CalciButton btnValue="+" displayInput={this.displayUserInput}/> <br/><br/>
            <CalciButton btnValue="4" displayInput={this.displayUserInput}/> <CalciButton btnValue="5" displayInput={this.displayUserInput}/> <CalciButton btnValue="6" displayInput={this.displayUserInput}/> <CalciButton btnValue="-" displayInput={this.displayUserInput}/> <br/><br/>
            <CalciButton btnValue="1" displayInput={this.displayUserInput}/> <CalciButton btnValue="2" displayInput={this.displayUserInput}/> <CalciButton btnValue="3" displayInput={this.displayUserInput}/> <CalciButton btnValue="*" displayInput={this.displayUserInput}/> <br/><br/>
            <CalciButton btnValue="0" displayInput={this.displayUserInput}/> <CalciButton btnValue="=" displayOutput={this.displayUserOutput}/> <CalciButton btnValue="-Reset" clearDisplay={this.clearDisplayPanel}/>
            </pre>
        </div>);
    }
}

export default CalculatorContainer;