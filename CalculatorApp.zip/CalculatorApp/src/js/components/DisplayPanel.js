/**
 * Created by yashw on 25-03-2017.
 */

import React from 'react';

class DisplayPanel extends React.Component{
    render(){
        return(<input className="form-control input-lg" value={this.props.expression} type="text"/>);
    }
}

export default DisplayPanel;