/**
 * Created by yashw on 14-02-2017.
 */
export default {
    SENT_MESSAGE: 'sent message',
    CHANGE_EVENT: 'change'
}