/**
 * Created by yashw on 14-02-2017.
 */
import {Dispatcher} from 'flux';

export default new Dispatcher();
