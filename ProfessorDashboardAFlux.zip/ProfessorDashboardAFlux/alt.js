/**
 * Created by yashw on 13-04-2017.
 */
import Alt from 'alt';

export default new Alt();
