/**
 * Created by yashw on 31-03-2017.
 */
export default [
    {
        reasonId: 234,
        reason: "student spoke meticulously"
    },
    {
        reasonId: 43,
        reason: "student researched well"
    },
    {
        reasonId: 232,
        reason: "student understood the concept well"
    }
]