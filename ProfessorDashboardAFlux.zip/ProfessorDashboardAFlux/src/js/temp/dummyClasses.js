/**
 * Created by yashw on 13-04-2017.
 */
let classes = [{
    className: "IS-6465-001",
        classTime: "6pm - 10pm"
},
{
    className: "IS-6565-002",
        classTime: "2pm - 5pm"
},
{
    className: "IS-7465-003",
        classTime: "6pm - 9pm"
},
{
    className: "IS-6665-004",
        classTime: "3pm - 7pm"
},
{
    className: "IS-6465-005",
        classTime: "6pm - 9pm"
}]