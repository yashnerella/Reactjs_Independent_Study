/**
 * Created by yashw on 30-03-2017.
 */


export default [
    {
        id: 0,
        name: 'Captain America',
        blurb: 'Captain America represented the pinnacle of human physical perfection. He experienced a time when he was augmented to superhuman levels',
        image: 'http://i.annihil.us/u/prod/marvel/movies/civilwar/images/captainamerica_hero.png'
    },
    {
        id: 1,
        name: 'Iron Man',
        blurb: 'A billionaire industrialist and genius inventor, ',
        image: 'http://www.gstatic.com/tv/thumb/movieposters/170620/p170620_p_v8_ak.jpg'
    },
    {
        id: 2,
        name: 'Hulk',
        blurb: 'I am the strongest of all',
        image: 'https://upload.wikimedia.org/wikipedia/en/5/59/Hulk_%28comics_character%29.png'
    }
]
