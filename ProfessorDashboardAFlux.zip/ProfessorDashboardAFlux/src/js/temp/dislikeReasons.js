/**
 * Created by yashw on 31-03-2017.
 */

export default [
    {
        reasonId: 23434,
        reason: "student did not speak meticulously"
    },
    {
        reasonId: 4334,
        reason: "student did not research well"
    },
    {
        reasonId: 233662,
        reason: "student did not understand the concept well"
    }
]