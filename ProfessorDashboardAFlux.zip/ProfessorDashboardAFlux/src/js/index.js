/**
 * Created by yashw on 17-03-2017.
 */

import React from 'react';
import ReactDOM from 'react-dom';
import App from './components/App';



ReactDOM.render(<App/>,document.getElementById("root"));
