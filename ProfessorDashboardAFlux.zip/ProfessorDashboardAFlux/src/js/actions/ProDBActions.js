/**
 * Created by yashw on 13-04-2017.
 */
import Alt from '../../../alt';

class ProDBActions{
    addClass(classObj){
        return classObj;
    }

    showAddClass(){
        return null;
    }

    changeSearchClassString(searchString){
        return searchString;
    }
}

export default Alt.createActions(ProDBActions);
