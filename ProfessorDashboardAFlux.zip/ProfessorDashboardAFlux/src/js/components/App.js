/**
 * Created by yashw on 30-03-2017.
 */
import React, {Component} from 'react';

import ProfessorDashboard from './ProfessorDashboard';

export default class App extends Component{

    render(){
        return(
            <div>
                <ProfessorDashboard/>
            </div>
        );
    }
}