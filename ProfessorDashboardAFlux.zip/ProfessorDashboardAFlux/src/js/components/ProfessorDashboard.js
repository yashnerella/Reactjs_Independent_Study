/**
 * Created by yashw on 06-04-2017.
 */
import React, {Component} from 'react';

import ProfessorBanner from './ProfessorBanner';
import ProfessorHome from './ProfessorHome';

export default class ProfessorDashboard extends Component{
    render(){
        return(
            <div>
                <ProfessorBanner/>
                <ProfessorHome/>
            </div>
        );
    }
}