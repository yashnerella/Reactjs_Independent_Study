/**
 * Created by yashw on 06-04-2017.
 */
import React, {Component} from 'react';
import {Navbar, Nav, NavItem, NavDropdown, FormControl, InputGroup, Button, MenuItem} from 'react-bootstrap';
import {Link} from 'react-router';

import ProDBActions from '../actions/ProDBActions';

export default class ProfessorBanner extends Component{
    handleSearchStringChange(e){
        ProDBActions.changeSearchClassString(e.target.value);
    }

    handleAddClass(){
        ProDBActions.showAddClass();
    }

    render(){
        return(
            <Navbar inverse collapseOnSelect>
                <Navbar.Header>
                    <Navbar.Brand>
                        <img width={150} height={100} src={require('../../../media/cd.png')}/>
                    </Navbar.Brand>
                    <Navbar.Toggle />
                </Navbar.Header>
                <Navbar.Collapse>
                    <Nav>
                        <NavItem eventKey={2} onClick={this.handleAddClass.bind(this)}>Add Class</NavItem>
                    </Nav>
                    <Navbar.Form pullLeft>
                        <InputGroup>
                            <FormControl onChange={this.handleSearchStringChange.bind(this)} type="text" placeholder="Search for a class..." />
                        </InputGroup>
                    </Navbar.Form>
                    <Nav pullRight>
                        <NavDropdown eventKey={3} title="Yashwant Nerella" id="basic-nav-dropdown">
                            <MenuItem eventKey={3.1}>Profile Settings</MenuItem>
                            <MenuItem divider />
                            <MenuItem eventKey={3.2}>Logout</MenuItem>
                        </NavDropdown>
                    </Nav>
                </Navbar.Collapse>
            </Navbar>
        );
    }
}