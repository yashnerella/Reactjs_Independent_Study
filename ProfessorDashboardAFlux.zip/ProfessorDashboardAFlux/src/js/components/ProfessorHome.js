/**
 * Created by yashw on 06-04-2017.
 */
import React,{Component} from 'react';
import {Panel, Button} from 'react-bootstrap';

import ProfessorAddClass from './ProfessorAddClass';

import classesStore from '../stores/classesStore';

export default class ProfessorHome extends Component{
    constructor(){
        super();
        this.state= {
            classArray: [],
            searchString: "",
        }
    }

    componentDidMount() {
        classesStore.listen(this.onChange.bind(this));
    }

    componentWillUnmount() {
        classesStore.unlisten(this.onChange.bind(this));
    }

    onChange(state) {
        this.setState({
            classArray: state.classes,
            searchString: state.searchString
        });
    }

    handleClassesDisplay(){
        let searchString = this.state.searchString;
        if(this.state.classArray.length == 0){
            return <div>There are no classes for you. Add Classes to your profile by clicking the "Add Class" link above</div>
        }
        else{
            let filteredClasses = this.state.classArray.filter(
                function checkIfSearchStringMatchesClass(classObj){
                    return classObj.className.includes(this);
                }, searchString);
            return filteredClasses.map(
                (classDetails, id)=> <div key={id}><Button bsStyle="default" bsSize="large">{classDetails.className}<br/>{classDetails.classTiming}</Button><br/><br/></div>
            )
        }
    }

    render(){
        return(
            <Panel header="Your Classes..." bsStyle="default" className="col-sm-8 classesPanel">
                {this.handleClassesDisplay()}
                <ProfessorAddClass/>
            </Panel>
        );
    }
}
