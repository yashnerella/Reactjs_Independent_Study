/**
 * Created by yashw on 06-04-2017.
 */
import React, {Component} from 'react';
import {Modal, Button, ControlLabel, Form, FormControl, FormGroup, HelpBlock} from 'react-bootstrap';
import DatePicker from 'react-bootstrap-date-picker';
import joi from 'joi';
import Xlsx from 'xlsx';

import ProDBActions from '../actions/ProDBActions';
import classesStore from '../stores/classesStore';

{/*USED VERY BAD CODING PRACTICES! WILL HAVE TO REWRITE THE CODE LATER - Yash on 04/14
   JOI VALIDATIONS ARE IMPLEMENTED BUT NOT ENFORCED! SHALL DO THAT AS WELL - Yash on 04/14*/}


export default class ProfessorAddClass extends Component{
    constructor(){
        super();
        this.className = "";
        this.classStartTime = "";
        this.classEndTime = "";
        this.classTiming = "";
        this.classDOW = [];
        this.classStartDate = new Date();
        this.classEndDate = new Date();
        this.state = {
            className: "",
            classStartTime: "",
            classEndTime: "",
            classTiming: "",
            classDOW: [],
            classStartDate: "",
            classEndDate: "",
            students: [],
            showAddClass: false,
            classNameValidationStatus: null,
            classSTValidationStatus: null,
            classETValidationStatus: null,
            classDOWValidationStatus: null,
            classSEDValidationStatus: null,
            classFileValidationStatus: null
        };
    }

    componentDidMount() {
        classesStore.listen(this.onChange.bind(this));
    }

    componentWillUnmount() {
        classesStore.unlisten(this.onChange.bind(this));
    }

    onChange(state) {
        this.setState({
            showAddClass: state.showAddClass
        });
    }

    handleAddClass(){
        this.state.classTiming = this.state.classStartTime + "-" + this.state.classEndTime;
        console.log(this.state);
        let classObj = this.state;
        ProDBActions.addClass(classObj);
        ProDBActions.showAddClass();
        this.setState({
            className: "",
            classStartTime: "",
            classEndTime: "",
            classTiming: "",
            classDOW: [],
            classStartDate: "",
            classEndDate: "",
            showAddClass: false,
            classNameValidationStatus: null,
            classCTValidationStatus: null,
            classDOWValidationStatus: null,
            classSDValidationStatus: null,
            classEDValidationStatus: null,
            classFileValidationStatus: null
        });
    }

    handleCancelButton(){
        ProDBActions.showAddClass();
        this.setState({
            className: "",
            classStartTime: "",
            classEndTime: "",
            classTiming: "",
            classDOW: [],
            classStartDate: "",
            classEndDate: "",
            showAddClass: false,
            classNameValidationStatus: null,
            classCTValidationStatus: null,
            classDOWValidationStatus: null,
            classSDValidationStatus: null,
            classEDValidationStatus: null,
            classFileValidationStatus: null
        });
    }

    handleClassNameChange(e){
        this.className = e.target.value;
        let result = joi.string().min(5).max(25).required().validate(this.className);
        if(result.error){
            this.setState({
                classNameValidationStatus: "error"
            });
        } else{
            this.setState({
                className: this.className,
                classNameValidationStatus: "success"
            });
        }
    }

    handleClassClassTimeChange(e){
        let result = null;
        if(e.target.id == "startTime"){
            this.classStartTime = e.target.value;
            result = joi.required().validate(this.classStartTime);
            if(result.error){
                this.setState({
                    classCTValidationStatus: "error"
                });
            } else{
                this.setState({
                    classStartTime: this.classStartTime,
                    classCTValidationStatus: "success"
                });
            }
        }
        else if(e.target.id == "endTime"){
            this.classEndTime = e.target.value;
            result = joi.required().validate(this.classEndTime);
            if(result.error){
                this.setState({
                    classCTValidationStatus: "error"
                });
            } else{
                this.setState({
                    classEndTime: this.classEndTime,
                    classCTValidationStatus: "success"
                });
            }
        }
    }

    handleClassDOWChange(){
        let selected = document.querySelectorAll('#dow option:checked');
        this.classDOW = Array.from(selected).map((el) => el.value);
        let result = joi.required().validate(this.classDOW);
        if(result.error){
            this.setState({
                classDOWValidationStatus: "error"
            });
        }else{
            this.setState({
                classDOW: this.classDOW,
                classDOWValidationStatus: "success"
            });
        }
    }

    handleClassSDChange(isoDate,usFormattedDate){
        this.state.classStartDate = usFormattedDate;
        // this.classStartDate = usFormattedDate;
        // let result = joi.required().validate(this.classStartDate);
        // if(result.error){
        //     this.setState({
        //         classSEDValidationStatus: "error"
        //     });
        // } else{
        //     this.setState({
        //         classStartDate: this.classStartDate,
        //         classSEDValidationStatus: "success"
        //     });
        // }
    }

    handleClassEDChange(isoDate,usFormattedDate){
            this.state.classEndDate = usFormattedDate;
            // this.classEndDate = usFormattedDate;
            // let result = joi.required().validate(this.classEndDate);
            // if(result.error){
            //     this.setState({
            //         classSEDValidationStatus: "error"
            //     });
            // } else{
            //     this.setState({
            //         classEndDate: this.classEndDate,
            //         classSEDValidationStatus: "success"
            //     });
            // }
        }

    handleStudentFileUpload(){
        const file = this.fileUpoload.files[0];
        console.log(file);
        let workbook = Xlsx.read(file, {type : 'binary'});
        let result = {};
        workbook.SheetNames.forEach(function(sheetName) {
            let roa = Xlsx.utils.sheet_to_row_object_array(workbook.Sheets[sheetName]);
            if(roa.length > 0){
                result[sheetName] = roa;
            }
        });
        console.log(result);
    }

    render(){
        return(
            <Modal bsSize="large" show = {this.state.showAddClass} onHide={ProDBActions.showAddClass}>
                <Modal.Header closeButton>
                    <b>Add Class Details</b>
                </Modal.Header>
                <Modal.Body>
                    <Form inline>
                        <FormGroup validationState={this.state.classNameValidationStatus}>
                            <ControlLabel>Class Name</ControlLabel> <br/>
                            <FormControl onChange={this.handleClassNameChange.bind(this)} type="text"/>
                            <FormControl.Feedback/>
                            <HelpBlock>Use the official University class ID</HelpBlock>
                        </FormGroup>
                        <br/>
                        <FormGroup validationState={this.state.classCTValidationStatus}>
                            <ControlLabel>Class Timings: </ControlLabel><br/>
                            <FormControl componentClass="select" id="startTime" onChange={this.handleClassClassTimeChange.bind(this)}>
                                <option value=""> </option>
                                <option value="1">1</option>
                                <option value="2">2</option>
                                <option value="3">3</option>
                                <option value="4">4</option>
                                <option value="5">5</option>
                                <option value="6">6</option>
                                <option value="7">7</option>
                                <option value="8">8</option>
                                <option value="9">9</option>
                                <option value="10">10</option>
                                <option value="11">11</option>
                                <option value="12">12</option>
                            </FormControl>
                            <FormControl id="startTod" componentClass="select">
                                <option value=""> </option>
                                <option value="pm">pm</option>
                                <option value="am">am</option>
                            </FormControl>
                            &nbsp; - &nbsp;
                            <FormControl componentClass="select" id="endTime" onChange={this.handleClassClassTimeChange.bind(this)}>
                                <option value=""> </option>
                                <option value="1">1</option>
                                <option value="2">2</option>
                                <option value="3">3</option>
                                <option value="4">4</option>
                                <option value="5">5</option>
                                <option value="6">6</option>
                                <option value="7">7</option>
                                <option value="8">8</option>
                                <option value="9">9</option>
                                <option value="10">10</option>
                                <option value="11">11</option>
                                <option value="12">12</option>
                            </FormControl>
                            <FormControl id="endTod" componentClass="select">
                                <option value=""> </option>
                                <option value="pm">pm</option>
                                <option value="am">am</option>
                            </FormControl>
                            <HelpBlock>Select timings for your class</HelpBlock>
                        </FormGroup>
                        <br/>
                        <FormGroup validationState={this.state.classDOWValidationStatus}>
                            <ControlLabel>Class meets on</ControlLabel> <br/>
                            <FormControl id="dow" componentClass="select" multiple onChange={this.handleClassDOWChange.bind(this)}>
                                <option value="mon">Monday</option>
                                <option value="tue">Tuesday</option>
                                <option value="wed">Wednesday</option>
                                <option value="thu">Thursday</option>
                                <option value="fri">Friday</option>
                                <option value="sat">Saturday</option>
                                <option value="sun">Sunday</option>
                            </FormControl>
                            <HelpBlock>Select multiple days using CTRL button on your keyboard</HelpBlock>
                        </FormGroup>
                        <br/>
                        <FormGroup validationState={this.state.classSEDValidationStatus}>
                            <ControlLabel>Start Date</ControlLabel>
                            <span className="spacing"/>
                            <ControlLabel>End Date</ControlLabel> <br/>
                            <DatePicker id="startDate" onChange={this.handleClassSDChange.bind(this)}/> &nbsp;
                            <DatePicker id="endDate" onChange={this.handleClassEDChange.bind(this)}/>
                            <HelpBlock>Select start and end dates for your class.</HelpBlock>
                        </FormGroup>
                        <br/>
                        <FormGroup>
                            <ControlLabel>Add students to class: </ControlLabel>
                            <FormControl type="file" onChange={this.handleStudentFileUpload.bind(this)} inputRef={ref => {this.fileUpoload = ref;}} />
                            <HelpBlock>Only .xlsx file format supported. Max 1MB</HelpBlock>
                        </FormGroup>
                    </Form>
                </Modal.Body>
                <Modal.Footer>
                    <Button bsStyle="default" onClick={this.handleAddClass.bind(this)}>Add Class</Button>
                    <Button bsStyle="default" onClick={this.handleCancelButton.bind(this)}>Cancel</Button>
                </Modal.Footer>
            </Modal>
        );
    }
}
