/**
 * Created by yashw on 13-04-2017.
 */
import Alt from '../../../alt';
import ProDBActions from '../actions/ProDBActions';

class classesStore{
    constructor(){
        this.classes = [];
        this.showAddClass = false;
        this.searchString = "";
        this.bindListeners({
            handleAddClass: ProDBActions.ADD_CLASS,
            handleShowAddClass: ProDBActions.SHOW_ADD_CLASS,
            handleChangeSearchString: ProDBActions.CHANGE_SEARCH_CLASS_STRING
        });
    }

    handleAddClass(classObj){
        this.classes.push(classObj);
    }

    handleShowAddClass(){
        this.showAddClass = !this.showAddClass;
    }

    handleChangeSearchString(searchString){
        this.searchString = searchString;
    }
}

export default Alt.createStore(classesStore, 'classesStore');
