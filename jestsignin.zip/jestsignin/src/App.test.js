import React from 'react';
import ReactDOM from 'react-dom';
import {mount, shallow} from 'enzyme';
import TestUtils from 'react-dom/test-utils';


import App from './App';


describe('Signup App renders?', ()=>{
    it('App renders without crashing', () => {
        const div = document.createElement('div');
        ReactDOM.render(<App />, div);
    });
});

describe('Whether sign up form renders?', ()=>{

    it('Signup form renders without crashing', ()=>{
        expect(mount(<App/>).find('#signup').length).toBe(1);
    });

    it('renders first name box', ()=>{
        expect(mount(<App/>).find('#fname').length).toBe(1);
    });

    it('renders last name box', ()=>{
        expect(mount(<App/>).find('#lname').length).toBe(1);
    });

    it('renders username box', ()=>{
        expect(mount(<App/>).find('#uname').length).toBe(1);
    });

    it('renders email box', ()=>{
        expect(mount(<App/>).find('#email').length).toBe(1);
    });

    it('renders password box', ()=>{
        expect(mount(<App/>).find('#pwd').length).toBe(1);
    });

    it('renders duplicate password box', ()=>{
        expect(mount(<App/>).find('#pwd2').length).toBe(1);
    });

    it('renders male gender radio button', ()=>{
        expect(mount(<App/>).find('#mrbtn').length).toBe(1);
    });

    it('renders female gender radio button', ()=>{
        expect(mount(<App/>).find('#frbtn').length).toBe(1);
    });

    it('renders signup button', ()=>{
        expect(mount(<App/>).find('#subtn').length).toBe(1);
    });
});

describe('Behaviour of Signup form', ()=>{

    it('All validation states should be set to "error" when the form renders for first time',()=>{
        const app = mount(<App/>);
        expect(app.state()).toMatchObject({
            fname: '',
            lname: '',
            uname: '',
            email: '',
            pwd: '',
            pwd2: '',
            gender: 'm',
            fnamevs: 'error',
            lnamevs: 'error',
            unamevs: 'error',
            pwdvs: 'error',
            pwd2vs: 'error',
            emailvs: 'error'
        });
    });

    it('first name box should take only letters',()=>{
        //--Using React Test Utils
        // const spy = jest.fn();
        // const app = TestUtils.renderIntoDocument(<App/>);
        // const fname = TestUtils.findRenderedDOMComponentWithClass(app,'fname');
        // TestUtils.Simulate.change(fname, {target: {value: 'yash'}});
        // console.log(app.state);

        //Using shallow of Enzyme library
        // const app = shallow(<App/>);
        // const fname = app.find('.fname');
        // fname.simulate('change', {target: {value:'yash'}});
        // console.log(app.state().fnamevs);

        //--Using mount of Enzyme library
        const app = mount(<App/>);
        const fname = app.find('#fname');
        fname.simulate('change', {target: {value: '12yash'}});
        expect(app.state().fname).not.toMatch(new RegExp(/^[a-zA-Z]+$/g));
    });

    it('first name box should not be empty',()=>{
        const app = mount(<App/>);
        const fname = app.find('#fname');
        fname.simulate('change', {target: {value: ''}});
        expect(app.state().fname).not.toMatch(new RegExp(/^[a-zA-Z]+$/g));
    });

    it('last name box should take only letters',()=>{
        const app = mount(<App/>);
        const lname = app.find('#lname');
        lname.simulate('change', {target: {value: 'nerella'}});
        console.log(lname.closest('.form-group').length);
        console.log(lname.parent());
        //expect(app.state().lnamevs).toBe('success');
        //expect(app.state().lname).toMatch(new RegExp(/^[a-zA-Z]+$/g));
    });

    it('last name box should not be empty',()=>{
        const app = mount(<App/>);
        const lname = app.find('#lname');
        lname.simulate('change', {target: {value: ''}});
        expect(app.state().lname).not.toMatch(new RegExp(/^[a-zA-Z]+$/g));
    });

    it('user name box should contain only letters and numbers',()=>{
        const app = mount(<App/>);
        const uname = app.find('#uname');
        uname.simulate('change', {target: {value: 'yash2907%#@#'}});
        expect(app.state().uname).not.toMatch(new RegExp(/(?=^.{8,15}$)(?!.*[!@#$%^&*]+)([A-Za-z0-9])\w+/g));
    });

    it('user name box should have a minimum length of 8 characters',()=>{
        const app = mount(<App/>);
        const uname = app.find('#uname');
        uname.simulate('change', {target: {value: 'yash'}});
        expect(app.state().uname).not.toMatch(new RegExp(/(?=^.{8,15}$)(?!.*[!@#$%^&*]+)([A-Za-z0-9])\w+/g));
    });

    it('user name box should have a maximum length of 15 characters',()=>{
        const app = mount(<App/>);
        const uname = app.find('#uname');
        uname.simulate('change', {target: {value: 'yash3124#@sdfsdfssdf'}});
        expect(app.state().uname).not.toMatch(new RegExp(/(?=^.{8,15}$)(?!.*[!@#$%^&*]+)([A-Za-z0-9])\w+/g));
    });
});