import React, { Component } from 'react';
import {Well, ControlLabel, FormControl, FormGroup, Radio} from 'react-bootstrap';

import logo from './logo.svg';
import './App.css';

class App extends Component {
  constructor(){
        super();
        this.state = {
            fname: '',
            lname: '',
            uname: '',
            email: '',
            pwd: '',
            pwd2: '',
            gender: 'm',
            fnamevs: 'error',
            lnamevs: 'error',
            unamevs: 'error',
            pwdvs: 'error',
            pwd2vs: 'error',
            emailvs: 'error'
        };
  }

  handleFnameChange(e){
      let stateUpdatedPromise = new Promise((resolve, reject) => {
          this.setState({
              fname: e.target.value
          });
          resolve();
      });
      stateUpdatedPromise.then(()=>{
          if(!this.state.fname.match(new RegExp(/^[a-zA-Z]+$/g))){
              this.setState({fnamevs: 'error'});
          }else {
              this.setState({fnamevs: 'success'});
          }
      });
  }

  handleLnameChange(e){
      let stateUpdatedPromise = new Promise((resolve, reject) => {
          this.setState({
              lname: e.target.value
          });
          resolve();
      });
      stateUpdatedPromise.then(()=>{
          console.log('Lname tested');
          if(!this.state.lname.match(new RegExp(/^[a-zA-Z]+$/g))){
              console.log('Lname errenous');
              this.setState({lnamevs: 'error'});
          }else {
              console.log('Lname good');
              this.setState({lnamevs: 'success'});
          }
          console.log(this.state.lnamevs);
      });
  }

  handleGenderChange(e){
        this.setState({gender: e.target.value});
  }

  handleUnameChange(e){
      let stateUpdatedPromise = new Promise((resolve, reject) => {
          this.setState({
              uname: e.target.value
          });
          resolve();
      });
      stateUpdatedPromise.then(()=>{
          if(!this.state.uname.match(new RegExp(/(?=^.{8,15}$)(?!.*[!@#$%^&*]+)([A-Za-z0-9])\w+/g))){
              this.setState({unamevs: 'error'});
          }else {
              this.setState({unamevs: 'success'});
          }
      });
  }

  handleEmailChange(e){
      let stateUpdatedPromise = new Promise((resolve, reject)=>{
          this.setState({
              email: e.target.value
          });
          resolve();
      });

      stateUpdatedPromise.then(()=>{
          if(!this.state.email.match(new RegExp(/[a-zA-Z0-9_\.-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9\.]{2,5}$/))){
              this.setState({emailvs: 'error'});
          }else {
              this.setState({emailvs: 'success'});
          }
      });
  }

  handlePwdChange(e){
      let stateUpdatedPromise = new Promise((resolve, reject) => {
          this.setState({
              pwd: e.target.value
          });
          resolve();
      });

      stateUpdatedPromise.then(()=>{
          if(!this.state.pwd.match(new RegExp(/(?=^.{8,}$)(?=.*\d)(?=.*[!@#$%^&*]+)(?![.\n])(?=.*[A-Z])(?=.*[a-z]).*$/))){
              this.setState({pwdvs: 'error'});
          }else {
              this.setState({pwdvs: 'success'});
          }
      });
  }

  handlePwd2Change(e){
      let stateUpdatedPromise = new Promise((resolve,reject)=>{
          this.setState({
              pwd2: e.target.value
          });
          resolve();
      });

      stateUpdatedPromise.then(()=>{
          if(this.state.pwd2 !== this.state.pwd){
              this.setState({pwd2vs: 'error'});
          }else{
              this.setState({pwd2vs: 'success'});
          }
      });
  }

  handleLoginClick(e){
      e.preventDefault();
      if(this.state.fnamevs === "error"||
         this.state.lnamevs === "error"||
         this.state.unamevs === "error"||
         this.state.emailvs === "error"||
         this.state.pwdvs === "error"||
         this.state.pwd2vs  === "error"){
          alert('page has errors');
      } else {
          alert('page has no errors');
          this.setState({
              fname: '',
              lname: '',
              uname: '',
              email: '',
              pwd: '',
              pwd2: '',
              gender: 'm',
              fnamevs: 'error',
              lnamevs: 'error',
              unamevs: 'error',
              pwdvs: 'error',
              pwd2vs: 'error',
              emailvs: 'error'
          });
      }
  }

  render() {
      return (
      <div className="App">
        <div className="App-header">
          <img src={logo} className="App-logo" alt="logo" />
          <h2>Validating user forms and testing the validation using JEST</h2>
        </div>
        <hr/>
        <br/>
        <br/>
        <div className="col-md-3 signupform">
            <Well>
                <h2>Signup Form</h2><br/><br/>
                <form id="signup">
                    <FormGroup validationState={this.state.fnamevs}>
                        <ControlLabel>First name</ControlLabel>
                        <FormControl id="fname"
                                     type="text"
                                     value={this.state.fname}
                                     placeholder="enter first name"
                                     onChange={this.handleFnameChange.bind(this)}
                                     onBlur={this.handleFnameChange.bind(this)}
                        /><br/>
                    </FormGroup>
                    <FormGroup controlId="lname" validationState={this.state.lnamevs}>
                        <ControlLabel>Last name</ControlLabel>
                        <FormControl
                                     type="text"
                                     value={this.state.lname}
                                     placeholder="enter last name"
                                     onChange={this.handleLnameChange.bind(this)}
                                     onBlur={this.handleLnameChange.bind(this)}
                        /><br/>
                    </FormGroup>
                    <FormGroup validationState={this.state.unamevs}>
                        <ControlLabel>Enter Username</ControlLabel>
                        <FormControl id="uname"
                                     type="text"
                                     value={this.state.uname}
                                     placeholder="enter username"
                                     onChange={this.handleUnameChange.bind(this)}
                                     onBlur={this.handleUnameChange.bind(this)}
                        /><br/>
                    </FormGroup>
                    <FormGroup validationState={this.state.emailvs}>
                        <ControlLabel>Enter Email</ControlLabel>
                        <FormControl id="email"
                                     type="text"
                                     value={this.state.email}
                                     placeholder="enter email"
                                     onChange={this.handleEmailChange.bind(this)}
                                     onBlur={this.handleEmailChange.bind(this)}
                        /><br/>
                    </FormGroup>
                    <FormGroup validationState={this.state.pwdvs}>
                        <ControlLabel>Enter Password</ControlLabel>
                        <FormControl id="pwd"
                                     type="password"
                                     value={this.state.pwd}
                                     placeholder="enter password"
                                     onChange={this.handlePwdChange.bind(this)}
                                     onBlur={this.handlePwdChange.bind(this)}
                        /><br/>
                    </FormGroup>
                    <FormGroup validationState={this.state.pwd2vs}>
                        <ControlLabel>Re-Enter Password</ControlLabel>
                        <FormControl id="pwd2"
                                     type="password"
                                     value={this.state.pwd2}
                                     placeholder="re-enter password"
                                     onChange={this.handlePwd2Change.bind(this)}
                                     onBlur={this.handlePwd2Change.bind(this)}
                        /><br/>
                    </FormGroup>
                    <FormGroup>
                        <ControlLabel>Choose Gender</ControlLabel><br/>
                        <Radio id="mrbtn"
                               name="gender"
                               value="m"
                               onChange={this.handleGenderChange.bind(this)}
                               checked={this.state.gender === 'm'}
                               inline>
                            Male
                        </Radio>
                        {' '}
                        <Radio id="frbtn"
                               name="gender"
                               value="f"
                               onChange={this.handleGenderChange.bind(this)}
                               checked={this.state.gender === 'f'}
                               inline>
                            Female
                        </Radio>
                    </FormGroup>
                    <FormGroup>
                        <FormControl id="subtn"
                                     type="submit"
                                     value="Sign Up"
                                     onClick={this.handleLoginClick.bind(this)}
                        />
                    </FormGroup>
                </form>
            </Well>
        </div>
        <div className="col-md-6 instructions">
            <Well>
                <code>
                <b>Note:</b> <br/><hr/>
                <b>First name</b> - should contain only letters | mandatory <br/>
                <b>Last name</b> - should contain only letters | mandatory <br/>
                <b>User name</b> - should contain only letters & digits | min 8 chars, max 15 chars | mandatory <br/>
                <b>Email</b> - standard email format | mandatory <br/>
                <b>Password</b> - should contain upcase, lowcase, allowed special characters, numbers | min 8 chars long | mandatory <br/>
                </code>
            </Well>
        </div>
      </div>
    );
  }
}

export default App;
