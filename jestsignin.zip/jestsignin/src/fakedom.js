/**
 * Created by yashw on 04-05-2017.
 */
import jsdom from 'jsdom';

function setupDom(){
    if(typeof document === 'undefined' ){
        global.document = jsdom.JSDOM('<html><body></body></html>')
        global.window = document.defaultView;
        global.navigator = window.navigator;
    }
}

setupDom();