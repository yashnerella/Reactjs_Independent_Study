RUNNING AND TESTING THE APP
----------------------------------------------
Install dependencies: "yarn install"
To start the app: "yarn start"
To test the app: "yarn test"

APPROACH TO TEST
----------------------------------------------

Testing was done in terms of "App Structure" & "App Behaviour"

I am totally satisfied with the testing in terms of App structure. But when it comes to
testing the behaviour of the validation, I am not 100% satisfied with what has been done.

Reason:
    When a change event is simulated, the onChange event handler should be called.
    That is done perfectly. (please check terminal for console.log messages from handleLnameChange function)
    Now, we can say that the behaviour is perfectly alright when the lnamevs(lastname validation status)
    changes to "error" or "success" accordingly (depends on our entered value).
    To check that there are two ways:

    1. app.state().lnamevs in "App.test.js"
    2. validationState prop on the FormGroup component in "App.js"

    - option 1 will not work because, the rendering that we do in App.test.js is not on a real DOM.
      The "simulate" function will not change the state of the shallow rendered component

    - option 2 should work. BUT there is a bug in Enzymes code library. The .parent(), .closest() functions
      broke sometime ago and there is no fix for it yet. To access the "validationState" prop of a particular
      react element I need to get the parent first. When I try to access the parent I get the following error:

        TypeError: Cannot read property 'reverse' of null

              at parentsOfInst (node_modules\enzyme\build\MountedTraversal.js:257:32)
              at ReactWrapper.<anonymous> (node_modules\enzyme\build\ReactWrapper.js:922:54)
              at ReactWrapper.single (node_modules\enzyme\build\ReactWrapper.js:1421:25)
              at ReactWrapper.parents (node_modules\enzyme\build\ReactWrapper.js:921:41)
              at ReactWrapper.closest (node_modules\enzyme\build\ReactWrapper.js:958:48)
              at Object.it (src\App.test.js:113:27)

      Folks at AirBnb agreed that it is a bug on their end and people are waiting for a fix.
      https://github.com/airbnb/enzyme/issues/410
      https://github.com/airbnb/enzyme/pull/769



I did not test the validations for email, password 1, password 2 becaus I felt it is unecessary when
I am not doing it the right way
