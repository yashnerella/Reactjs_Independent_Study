/**
 * Created by yashw on 28-02-2017.
 */

const blogActionTypes = {
    SUBMIT_POST: 'SUBMIT_POST',
    LIKE_POST: 'LIKE_POST',
    DISLIKE_POST: 'DISLIKE_POST',
    COMMENT_ON_POST: 'COMMENT_ON_POST'
};

export default blogActionTypes;
