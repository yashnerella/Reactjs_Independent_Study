/**
 * Created by yashw on 26-02-2017.
 */
import React, {Component} from 'react';
import {FormGroup, FormControl, ControlLabel, Radio, Button, Modal} from 'react-bootstrap';
import {bindActionCreators} from 'redux';
import {connect} from 'react-redux';
import Joi from 'joi';

import submitPost from '../actions/beforePostingActions';

class Postform extends Component {
    constructor(){
        super();
        this.state = {
            postObject: {
                id: 0,
                title: "",
                author: "",
                category: "Movies",
                gender: "",
                postContent: ""
            },
            showPostContentEntry: false,
            showCreatePostButton: true,
            showSubmitPostButton: true,
            errorMsg: ""
        };

        this._handleOnChangeTitle = this._handleOnChangeTitle.bind(this);
        this._handleOnChangeAuthor = this._handleOnChangeAuthor.bind(this);
        this._handleOnChangeCategory = this._handleOnChangeCategory.bind(this);
        this._handleOnChangeGender = this._handleOnChangeGender.bind(this);
        this._handleOnClickCreatePost = this._handleOnClickCreatePost.bind(this);
        this._handleOnChangePostContent = this._handleOnChangePostContent.bind(this);
        this._handleOnClickSubmitPost = this._handleOnClickSubmitPost.bind(this);
    }

    _handleOnChangeTitle(event){
        let postObject = this.state.postObject;
        postObject.title = event.target.value;
        this.setState({
            postObject: postObject
        });
    }
    _handleOnChangeAuthor(event){
        let postObject = this.state.postObject;
        postObject.author = event.target.value;
        this.setState({
            postObject: postObject
        });
    }
    _handleOnChangeCategory(event){
        let postObject = this.state.postObject;
        postObject.category = event.target.value;
        this.setState({
            postObject: postObject
        });
    }
    _handleOnChangeGender(changeEvent){
        let postObject = this.state.postObject;
        postObject.gender = changeEvent.target.value;
        this.setState({
            postObject: postObject
        });
    }
    _handleOnClickCreatePost(){
        this.setState({
            showPostContentEntry: true
        });
    }
    _handleOnChangePostContent(event){
        let postObject = this.state.postObject;
        postObject.postContent = event.target.value;
        this.setState({
            postObject: postObject
        });
    }
    _handleOnClickSubmitPost(){
        let prevId = this.state.postObject.id;
        prevId++;
        let currId = prevId;
        let postObject = this.state.postObject;
        postObject.id = currId;
        this.setState({
            postObject: postObject
        });

        // Validating before sending the data to downstream
        const postSchema = Joi.object().keys({
            title: Joi.string().alphanum().min(10).max(50).required(),
            author: Joi.string().min(5).max(25).required(),
            category: Joi.string().valid(['Movies', 'Sports']).required(),
            gender: Joi.string().valid(['m', 'f']).required(),
            postContent: Joi.string().min(5).max(1000).required()
        });

        const result = Joi.validate(this.state.postObject, postSchema, {allowUnknown: true});

        if(result.error){
            alert("Form has errors! Please check and submit again" + result.error);
        }else{
            this.props.submitPost(this.state.postObject);
            this.setState({
                postObject: {
                    id: currId,
                    title: "",
                    author: "",
                    category: "Movies",
                    gender: "",
                    postContent: ""
                },
                showPostContentEntry: false,
                showCreatePostButton: true,
                showSubmitPostButton: true,
                errorMsg: ""
            });
        }
    }
    close() {
        this.setState({
            showPostContentEntry: false
        });
    }

    render() {
        return (
            <div className="container">
                <form>
                    <FormGroup controlId="userPostTitle">
                        <ControlLabel>Title of the post:</ControlLabel>
                        <FormControl type="text" placeholder="Enter the title of the post..." onChange={this._handleOnChangeTitle} value={this.state.postObject.title}/>
                    </FormGroup>
                    <FormGroup controlId="userPostAuthor">
                        <ControlLabel>Author of the post:</ControlLabel>
                        <FormControl type="text" placeholder="Enter your name..." onChange={this._handleOnChangeAuthor} value={this.state.postObject.author}/>
                    </FormGroup>
                    <FormGroup controlId="userPostCategory">
                        <ControlLabel>Category:</ControlLabel>
                        <FormControl componentClass="select" onChange={this._handleOnChangeCategory} value={this.state.postObject.category}>
                            <option value="Movies">Movies</option>
                            <option value="Sports">Sports</option>
                        </FormControl>
                    </FormGroup>
                    <FormGroup controlId="userGender">
                        <ControlLabel>Gender:</ControlLabel><br/>
                        <Radio name="genderGroup" value="m" inline onChange={this._handleOnChangeGender}>Male</Radio>
                        <Radio name="genderGroup" value="f" inline onChange={this._handleOnChangeGender}>Female</Radio>
                    </FormGroup>
                    <Button bsStyle="primary" onClick={this._handleOnClickCreatePost} disabled={!this.state.showCreatePostButton}>
                        Create Post
                    </Button>
                </form>
                <Modal bsSize="large" show={this.state.showPostContentEntry} onHide={this.close.bind(this)}>
                    <Modal.Header closeButton>
                        <Modal.Title>Type the content for your post below:</Modal.Title>
                    </Modal.Header>
                    <Modal.Body>
                        <FormGroup controlId="formControlsTextarea">
                            <FormControl bsSize="large" componentClass="textarea" placeholder="Enter your content here..." onChange={this._handleOnChangePostContent} value={this.state.postObject.postContent}/>
                        </FormGroup>
                    </Modal.Body>
                    <Modal.Footer>
                        <Button onClick={this.close.bind(this)}>Close</Button>
                        <Button bsStyle="primary"  onClick={this._handleOnClickSubmitPost} disabled={!this.state.showSubmitPostButton}>Submit Post</Button>
                    </Modal.Footer>
                </Modal>
            </div>
        );
    }
}

const mapDispatchToProps = (dispatch) => {
    return bindActionCreators({submitPost: submitPost},dispatch)
};

export default connect(null,mapDispatchToProps)(Postform);

