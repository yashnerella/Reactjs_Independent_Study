/**
 * Created by yashw on 26-02-2017.
 */
import React, {Component} from 'react';
import Postform from './Postform';
import Post from './Post';
import Posts from './Posts';
import Navbar from './Navbar';
import {Typeahead} from 'react-bootstrap-typeahead';
import {Button, Modal} from 'react-bootstrap';

import {connect} from 'react-redux';

class App extends Component{
    constructor(){
        super();
        this.state = {
            showSearchedPost: false,
            userSearchedPost: {}
        }
    }

    handleSearchInput(){
        let tglShw = this.state.showSearchedPost;
        this.setState({showSearchedPost: !tglShw});

        let searchedPost = this.props.posts.filter(
            function checkIfSearchStringMatchesPostTitle(postObj){
                return postObj.title.includes(this);
            }, this.refs.searchbar.getInstance().state.text);
        this.setState({userSearchedPost: searchedPost[0]});
    }

    handleModalClosure(){
        let tglShw = this.state.showSearchedPost;
        this.setState({showSearchedPost: !tglShw});
    }

    render(){
        return(
            <div>
                <Navbar/>
                <Postform/><hr/>
                <div>
                    <b>Search For a Topic:</b>
                    <Typeahead ref="searchbar" placeholder="select a topic.." align="justify" labelKey="title" options={this.props.posts} maxResults={3}/>
                    <Button bsStyle="primary" onClick={this.handleSearchInput.bind(this)}>Search</Button>
                </div>
                <Posts/>
                <Modal show={this.state.showSearchedPost} bsSize="large">
                    <Modal.Body>
                        <Post postDetails={this.state.userSearchedPost}/>
                    </Modal.Body>
                    <Modal.Footer>
                        <Button onClick={this.handleModalClosure.bind(this)}>Close</Button>
                    </Modal.Footer>
                </Modal>
            </div>
        );
    }
}

const mapStoreToProps = (store)=>{
    return {posts: store.posts}
};

export default connect(mapStoreToProps)(App);