/**
 * Created by yashw on 10-04-2017.
 */
function sendMsgToWatson() {
    var msg = document.getElementById("msg").value;
    if(msg == ""){
        alert("Please enter a message for watson!");
    }
    else{
        document.getElementById("formid").action = "/msgsenttowatson/" + msg;
    }
}