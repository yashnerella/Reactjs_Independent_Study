/**
 * Created by yashw on 10-04-2017.
 */
var express = require('express');
var async = require('async');

var router = express.Router();

//sets up service wrapper, sends initial message, and receives response.
var ConversationV1 = require('watson-developer-cloud/conversation/v1');

// Set up Conversation service wrapper.
var conversation = new ConversationV1({
    username: '60761839-5a95-408e-920f-c206c1061848',
    password: 'ERkJFLoFX3nS',
    path: { workspace_id: 'bb0c9418-9b3b-45b1-9b03-091d62460e88' },
    version_date: '2017-04-11'
});

//Watson response will be stored in this variable
var watsonResponse = "";
var watsonResponseContext = {};

// Process the conversation response.
// NOTE: THE RESPONSE OBJECT IN THIS METHOD IS NOT THE RESPONSE OBJECT OF THIS APP.
// IT IS THE RESPONSE COMING FROM WATSON API
var processResponsePromise = function(err, wresponse){
       if (err) {
           console.error(err); // something went wrong
           return new Promise(function (resolve,reject){
               reject("error from watson");
           });
       } else{
           //If an intent was detected, log it out to the console.
           if (wresponse.intents.length > 0) {
               console.log('Detected intent: #' + wresponse.intents[0].intent);
           }

           // Display the output from dialog, if any.
           if (wresponse.output.text.length != 0) {
               watsonResponse = wresponse.output.text[0];
               console.log(wresponse.output.text[0]);
           }

           watsonResponseContext = wresponse.context;

           return new Promise(function (resolve,reject){
               resolve("got response from watson");
           });
       }
};




router.get('/', function(req,res){
    conversation.message({}, function(err,wresponse){
        processResponsePromise(err,wresponse).then(function(successMessage){
            console.log(successMessage);
            res.render('welcome', {title: "YashWatsonChatApp", watsonResponse: watsonResponse});
            res.end();
        })
    });
});


router.get('/msgsenttowatson/:msg', function (req,res) {
    conversation.message({input:{text: req.params.msg}, context: watsonResponseContext}, function(err,wresponse){
        processResponsePromise(err,wresponse).then(function(successMessage){
            console.log(successMessage);
            res.render('welcome', {title: "YashWatsonChatApp", userMessage:req.params.msg, watsonResponse: watsonResponse});
            res.end();
        });
    });
});

module.exports = router;