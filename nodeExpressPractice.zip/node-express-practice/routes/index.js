/**
 * Created by yashw on 09-04-2017.
 */
var express = require('express');
var router = express.Router();
var path = require('path');

router.get('/', function(req,res,next){
    res.render('welcome', {title: "Node+Express App"});
    res.end();
});

module.exports = router;