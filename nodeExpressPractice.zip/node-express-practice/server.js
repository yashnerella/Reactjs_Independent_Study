/**
 * Created by yashw on 08-04-2017.
 */
var http = require('http');
var app = require('./app');

var server = http.createServer(app);
server.listen(3000);
