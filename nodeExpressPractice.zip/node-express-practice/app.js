/**
 * Created by yashw on 08-04-2017.
 */
var url = require('url');
var fs = require('fs');
var express = require('express');
var path = require('path');

var indexRoutes = require('./routes/index');


var app = express();

//setting the template engine
app.set('views',path.join(__dirname + '/views'));
app.set('view engine', 'pug');

app.use(express.static(path.join(__dirname + 'public')));

app.use('/',indexRoutes);

//catch 404 and forward to error handler
// app.use(function(req, res, next){
//    var err = new Error('Not Found');
//    err.status = 404;
//    console.log("Error Logged!");
//    console.log(path.join(__dirname+'/views/404.html'));
//    res.render(path.join(__dirname+'/views/404.html'));
//    res.end();
// });

module.exports = app;


//PRACTICE OF NODE.JS
// function renderHTML(path, response){
//     fs.readFile(path,null,function(error, data){
//         if(error){
//             response.writeHead(404);
//             response.write("File not Found!");
//         }
//         else{
//             response.writeHead(200,{'Content-Type': 'text/html'});
//             response.write(data);
//         }
//         response.end();
//     });
// }
//
// module.exports = {
//     handleRequest: function (request, response) {
//         var path = url.parse(request.url).pathname;
//         switch (path){
//             case '/': renderHTML('./index.html', response);
//                       break;
//             case '/other': renderHTML('./other.html', response);
//                            break;
//             default: response.writeHead(404);
//                      response.write("Route not Found!");
//                      response.end();
//                      break;
//         }
//     }
// };
// app.get('/', function (req, res) {
//     res.send('Hello World!')
// });
//
// app.get('/post', function (req, res) {
//     res.sendFile(path.join(__dirname+'/public/html/index.html'))
// });
//
// app.get('/users/:userId/books/:bookId', function (req, res) {
//     res.send(req.params)
// });
//
// app.get('/example/b', function (req, res, next) {
//     res.send("I also want to send data");
//     next();
// }, function (req, res) {
//     //res.send('Hello from B!')
//     console.log('the response was sent by the prev function ...');
// });