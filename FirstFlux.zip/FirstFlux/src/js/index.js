/**
 * Created by yashw on 11-02-2017.
 */
import React from 'react';
import {render} from 'react-dom';

import {App} from './components/App';

render(<App/>, document.getElementById('app'));