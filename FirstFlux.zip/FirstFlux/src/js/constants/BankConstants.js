/**
 * Created by yashw on 11-02-2017.
 */
export default {
    CREATED_ACCOUNT: 'created account',
    WITHDREW_FROM_ACCOUNT: 'withdrew from account',
    DEPOSITED_INTO_ACCOUNT: 'deposited into account',
    CHANGE_EVENT: 'change'
}