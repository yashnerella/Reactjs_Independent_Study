/**
 * Created by yashw on 11-02-2017.
 */
import {Dispatcher} from 'flux';

export default new Dispatcher();

{/*
export class BankAppDispatcher extends Dispatcher{
        dispatch(action){
            console.log("Dispatched",action);
            super.dispatch(action)
        }
 }
 */}